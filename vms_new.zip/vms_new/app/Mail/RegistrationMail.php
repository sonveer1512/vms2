<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class RegistrationMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $id;
    protected $name;

    /**
     * Create a new message instance.
     */
    public function __construct($id,$name)
    {
        $this->id = $id;
        $this->name = $name;
    }


    /**
     * Get the message content definition.
     */
    public function build() {
        $data['id'] = $this->id;
        $data['name'] = $this->name;
        return $this->subject('Registration Confirmation')->view('emails.registration_mail',$data);
    }

}
