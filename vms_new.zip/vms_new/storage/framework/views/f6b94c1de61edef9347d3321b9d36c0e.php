<?php if(!empty($list)): ?>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover-actions-trigger btn-reveal-trigger position-static">
                            <td><?php echo e($key+1); ?></td>
                            <td class="customer align-middle">
                                <label for="accred_<?php echo e($key+1); ?>">
                                    <?php if(!empty($value->upload_image)): ?>
                                    <img data-src="<?php echo e(asset('uploads/uploaded_image/'.$value->upload_image)); ?>" style="width: 100px; height: 100px; object-fit: cover" onerror="this.src='<?php echo e(asset('admins/img/noimage.jpg')); ?>'">
                                    <?php else: ?>
                                    <img data-src="<?php echo e(asset('uploads/captured_image/'.$value->camera_image)); ?>" style="width: 100px; height: 100px; object-fit: cover" onerror="this.src='<?php echo e(asset('admins/img/noimage.jpg')); ?>'">
                                    <?php endif; ?>
                                </label>
                            </td>
                            <td class="customer align-middle"><b><?php echo e($value->name ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->email ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->contact ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->city_1->name ?? ''); ?>,<?php echo e($value->state_1->name ?? ''); ?>,<?php echo e($value->country_1->name ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->company_nature ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->area_intrest ?? ''); ?></b></td>
                            <td class="customer align-middle"><b><?php echo e($value->event_info ?? ''); ?></b></td>
                            <?php if($value->vaccination_status == 1): ?>
                            <td class="customer align-middle"><b>
                                    <div class="badge badge-phoenix fs--2 badge-phoenix-success"><span class="fw-bold">Yes</span></div>
                                </b>
                            </td>
                            <?php else: ?>
                            <td>
                                <div class="badge badge-phoenix fs--2 badge-phoenix-warning"><span class="fw-bold">No</span></div>
                            </td>
                            <?php endif; ?>
                            <td class="align-middle white-space-nowrap text-700">
                                <?php
                                $date = date_create($value->created_at);
                                echo date_format($date,"j M, Y");
                                ?>
                            </td>
                            <td class="customer align-middle">
                                <!-- <button type="button" class="btn btn-sm btn-info" data-bs-target="#editmodal" data-bs-toggle="modal" onclick="showeditmodulediv('<?php echo e($value->id); ?>')"><span data-feather="edit-3"></span></button> -->

                                <?php if($value->flag == 1): ?>
                                <button class="btn btn-sm btn-success" data-bs-target="#deletepopup" data-bs-toggle="modal" onclick="deletepopup('<?php echo e($value->id); ?>','registration_data','activate')"><span data-feather="check"></span></button>
                                <?php else: ?>
                                <button class="btn btn-sm btn-warning" data-bs-target="#deletepopup" data-bs-toggle="modal" onclick="deletepopup('<?php echo e($value->id); ?>','registration_data','deactivate')"><span data-feather="alert-triangle"></span></button>
                                <?php endif; ?>

                                <button class="btn btn-sm btn-danger" data-bs-target="#deletepopup" data-bs-toggle="modal" onclick="deletepopup('<?php echo e($value->id); ?>','registration_data','delete')"><span data-feather="trash-2"></span></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?><?php /**PATH C:\laravelprojects\vms\resources\views/admins/user/filter.blade.php ENDPATH**/ ?>