<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>VISITOR MANAGEMENT SYSTEM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="img/favicon.ico.png" rel="icon" type="image/x-icon" />
    <link rel='stylesheet prefetch' href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/new/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/new/sb-admin-2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.numpad.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sb-admin-2.js')); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.12/sweetalert2.min.css" integrity="sha512-yX1R8uWi11xPfY7HDg7rkLL/9F1jq8Hyiz8qF4DV2nedX4IVl7ruR2+h3TFceHIcT5Oq7ooKi09UZbI39B7ylw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<style>
    .btnOtp {
        background-color: #28B6B7;
        border: 1px solid #28B6B7;
        border-radius: 2px;
        color: #ffffff;
        display: inline-block;
        margin: 5px;
        padding: 7px 10px;
        width: 100%;
    }

    .btn.focus,
    .btn:focus,
    .btn:hover {
        color: #fff;
        text-decoration: none;
    }

    .btnOtpQ {
        background-color: #3d7edb;
        border: 1px solid #3d7edb;
        border-radius: 3px;
        color: #ffffff;
        display: inline-block;
        margin: 5px;
        padding: 7px 10px;
        transition: all 0.5s ease 0s;
        width: 100%;
    }

    .btnOtpQ:hover {
        opacity: 0.9
    }

    .form-group label {
        color: #333;
    }

    .btn-new-back a {
        border-radius: 3px;
        color: #ffffff;
        display: block;
        float: right;
        font-size: 18px;
        margin-top: 2px;
        padding: 4px 23px;
        text-align: center;
        text-decoration: none;
    }

    .btn-new-back a img {
        width: 25px;
    }

    .btn-new-back a:hover {
        opacity: 0.9;
    }

    .imp {
        display: block;
        overflow: hidden;
        padding: 0 30px;
        position: relative;
        margin-bottom: 10px;
    }

    .sel {
        color: red;
        text-align: center;
    }

    .frame-image-on-click img {
        margin-top: 27px;
        width: 100%;
        box-shadow: 0px 2px 6px -1px #000;
    }

    .textcolor {
        color: #ffffff;
    }

    #img-results h2 {
        font-size: 18px;
        text-align: center;
        color: #fff;
        background: #451d04;
        margin: 0 auto -27px auto;
        padding: 10px 10px;
        border-radius: 10px 10px 0px 0px;
    }

    #img-results {
        margin-top: 30px;
    }

    .textcolor {
        color: white;
    }

    .left-1 {
        display: block;
        float: left;
        margin: 6px 5px 0px 0px;
        overflow: hidden;
        width: 100px;
    }

    .left-1 input {
        display: inline-block;
        float: left;
        width: 30px;
    }

    .left-1 span {
        float: left;
    }

    #suggesstion21 {
        background: #ffffff none repeat scroll 0 0;
        color: #000000;
        margin-top: 2px;
        padding: 0 10px;
        width: 100%;
    }

    #suggesstion12 {
        background: #ffffff none repeat scroll 0 0;
        color: #000000;
        margin-top: 2px;
        padding: 0 10px;
        width: 100%;
    }

    .video-button {
        background: #67615e;
        border: 1px solid #ffffff;
        border-radius: 3px;
        color: #ffffff;
        display: table;
        font-size: 13px;
        margin: 13px 0;
        padding: 7px 20px;
        transition: all 1s ease 0s;
    }

    .video-button:hover {
        background-color: #fff;
        border: 1px solid #67615e;
        color: #333;
    }

    .video-button:focus,
    .video-button:activ {
        background-color: #fff;
        border: 1px solid #67615e;
        color: #333;
    }

    .sel {
        color: red;
        text-align: center;
    }

    .flex-body {
        display: flex;
        width: 100%;
        justify-content: center;
        overflow: hidden;
    }

    .flex-body-left {
        width: 45%;
        margin: 10px;
    }

    .flex-body-left video {
        width: 100%;
        height: 250px;
    }

    .flex-body-right {
        width: 260px;
        overflow: hidden;
        height: 196px;
        margin-left: 6px;
        margin-top: 26px;
    }

    #canvas {
        display: inline-block;
        width: auto;
        height: 250px;
    }

    @media (max-width:678px) {
        .flex-body {
            display: block;
            width: 100%;
        }

        .flex-body-left {
            width: 100%;
        }

        .flex-body-left video {
            width: 100%;
            height: 250px;
        }

        .flex-body-right {
            width: 100%;
            margin: 10px;
        }

        #canvas {
            /*margin-top: 20px; margin-left: 100px; border: 1px solid #ccc;*/
            display: block;
            width: 100%;
            height: 250px;
        }
    }

    /*modal css */


    .terms-conditions {
        padding: 0 50px 0 20px;
        display: block;
    }

    .terms-conditions input {
        width: 12px;
        margin-right: 8px;
        display: inline-block;
        float: left;
    }

    .terms-conditions a {
        display: inline-block;
        float: left;
        font-size: 13px;
        color: #333;
    }

    .terms-conditions a:hover {
        cursor: pointer;
        text-decoration: none;
    }

    .visitor-instructions {}

    .visitor-instructions h4 {
        color: #fff;
        text-align: center;
    }

    .visitor-instructions .modal-dialog {
        margin: 66px auto;
        width: 60%;
    }

    .visitor-instructions ul li {
        list-style-type: disc;
        font-size: 14px;
        line-height: 25px;
    }

    .visitor-instructions ul {
        margin: 0;
    }

    .visitor-instructions .checkbox-area {
        padding-left: 40px;
    }

    .visitor-instructions .checkbox-area h4 {
        color: red;
    }

    .visitor-instructions .checkbox-area input {
        width: 12px;
        display: inline-block;
        float: left;
        margin-right: 8px;
    }

    .visitor-instructions .checkbox-area input[type=checkbox] {
        border-radius: none !important;
    }

    input[type=checkbox],
    input[type=radio] {

        margin-top: 1px\9;
        line-height: normal;
        -webkit-appearance: checkbox;
        height: 12px;
    }

    .button-block-b {
        display: inline-block;
        margin: 40px 0 10px;
        text-transform: none;
    }

    .dontagree {
        text-transform: none;
        background: #ff0000;
        border: 1px solid #ff0000;
        border-radius: 3px;
        color: #ffffff;
        display: inline-block;
        font-size: 14px;
        font-weight: 300;
        letter-spacing: 1px;
        margin: 8px 8px 10px;
        overflow: hidden;
        padding: 10px 20px;
        transition: all 1s ease 0s;
    }

    .footer {
        margin: 0 auto;
        text-align: center;
    }

    .visitor-instructions .agree {
        font-weight: 700;
    }

    .society-name {
        background: #0f69ae;
        color: #fff;
        height: 65px;
        margin-top: -21px;
    }



    h2 {
        font-size: 30px;
        text-align: center;
        margin-top: 20px;
        padding-top: 16px;
        font-weight: 600;
    }

    .section {
        padding: 10px;
        box-shadow: 0 2px 3px #ccc;
    }

    h1 {
        color: #333;
        line-height: 18px;
        font-weight: 600;
    }

    @media only screen and (max-device-width : 768px) and (max-device-width : 1024px) {
        h1 {
            font-size: 17px;
            font-weight: 600;
        }
    }

    p {
        font-weight: 600;
        text-align: -webkit-center;
    }

    .section {
        padding: 0;
        box-shadow: 0 2px 3px #ccc;
    }

    @media only screen and (max-device-width : 768px) and (max-device-width : 1024px) {
        h4 {
            font-size: 15px;
            font-weight: 600;
        }
    }

    @media (max-width:678px) {
        .flex-body {
            display: block;
            width: 100%;
            justify-content: center;
            overflow: hidden;
        }
    }

    .img-responsive {
        display: block;
        max-width: 100%;
        height: 315px;
        width: 100%;
    }
</style>

<html style="background:url('img/lp.jpg') no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">

<script type="text/javascript" src="<?php echo e(asset('js/web/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/web/webcam.min.js')); ?>"></script>

<body style="background-color:transparent;">
    <div class="container">
        <div class="main-file-v">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <section class="section">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12" style="padding-left: 0;padding-right: 0;">
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <center>
                                    <div class="imp">
                                        <h1 style="text-align:center;">Visitor Management System</h1>

                                    </div>
                                </center>
                            </div>

                        </div>
                    </section>
                    <br />
                </div>

                <form name="add_visitors" id="add_visitors" class="form-horizontal" method="POST" action="#" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="imp">
                        <div class="row">
                            <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="name" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">Name<span class="sel">* </span></label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <input type="text" name="name" id="name" class="form-control" spellcheck="false" value="" placeholder="Enter Name" />
                                        <span id="name_error" class="error"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">Email<span class="sel">* </span></label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <input type="email" name="email" id="email" class="form-control" spellcheck="false" value="" placeholder="Enter Email" />
                                        <span id="email_error" class="error"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="contact" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">Mobile<span class="sel">* </span></label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <input type="number" name="contact" id="contact" class="form-control" spellcheck="false" value="" placeholder="Enter Mobile Number" />
                                        <span id="contact_error" class="error"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="contact" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">Image</label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <input type="file" name="uploaded_image" id="uploaded_image" class="form-control" spellcheck="false" value="" />
                                    </div>
                                </div>

                            </div>
                            <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">

                                <div class="form-group">
                                    <label for="name" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">Country <span class="sel">* </span></label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <select name="country_id" class="form-control countries" id="country_id" onchange="get_state(this.value,'country');">
                                            <option value="">Select Country</option>
                                            <?php $country = App\Models\CountryModel::all(); ?>
                                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span id="country_id_error" class="error"></span>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="name" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">State</label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <select id="state" name="state" class="form-control country" onchange="get_city(this.value,'state')">
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor">City</label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <select id="city" name="city" class="form-control state">
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <p><input type="checkbox" id="terms" name="terms" value="1" style="float: left;width: 4%;">By ticking this box you confirm that you agree to our <a target="_blank" href="https://zmzevents.com/general-terms-and-conditions/"> terms and conditions </a> applicable to you visit at our events and acknowledge that you have read our <a target="_blank" href="https://zmzevents.com/privacy-policy/"> Privacy Policy</a>.</p>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-sm-12 col-xs-12 col-md-6 col-lg-12">
                                <h3><b>Business details::</b></h3>
                            </div>
                            <div class="col-sm-6 col-xs-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="contact" class="col-xs-12 col-sm-4 col-md-4 col-md-6 control-label textcolor">What is the nature of your company business?</label>
                                        <div class="col-xs-12 col-sm-12 col-md-8">
                                            <input type="text" name="company_nature" id="company_nature" class="form-control" spellcheck="false" value="" placeholder="Enter nature of your company business" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12 col-md-6 col-lg-6">
                                <div class="form-group">
                                    <label for="contact" class="col-xs-12 col-sm-4 col-md-4 col-md-6   control-label textcolor">What are the main areas of your interest?</label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <input type="text" name="area_intrest" id="area_intrest" class="form-control" spellcheck="false" value="" placeholder="Enter areas of your interest" />
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-xs-12">
                                <div class="form-group">
                                    <h4>How did you learn about the event?</h4>
                                    <label class="checkbox-inline">

                                        <input type="checkbox" name="event_source[]" value="Recommended by colleague/friend">&nbsp;
                                        <label for="vehicle5">Recommended by colleague/friend</label><br>

                                        <input type="checkbox" name="event_source[]" value="Google Search">&nbsp;
                                        <label for="vehicle5">Google Search</label><br>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-xs-12">
                                <div class="form-group">
                                    <label for="name" class="col-xs-12 col-sm-4 col-md-4 control-label textcolor" id="label"><b>Vaccination Done</b></label>
                                    <div class="col-xs-12 col-sm-12 col-md-8">
                                        <label class="radio-inline">
                                            <input type="radio" name="vaccination" value="1" style="margin-left:-20px;width: 25%;">Yes
                                        </label>
                                        <label class="radio-inline">
                                            <input type="radio" name="vaccination" value="0" style="margin-left:-20px;width: 25%;">No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                                <div class="form-group">
                                    <div class="flex-body">
                                        <div class="flex-body-left">
                                            <div id="my_camera"></div>

                                            <div style="clear:both; padding:20px;"></div>
                                            <button type="button" value="Take Snapshot" class="video-button" onClick="take_snapshot()"> <i class="fa fa-picture-o" aria-hidden="true"></i> Capture Photo</button>

                                            <input type="hidden" name="image" id="captured_image" class="image-tag">
                                            <div style="clear:both; padding:10px;"></div>

                                        </div>

                                        <div class="flex-body-right">
                                            <div id="results_img"></div>
                                        </div>

                                    </div>
                                </div>

                                <!-- Configure a few settings and attach camera -->
                                <script language="JavaScript">
                                    Webcam.set({
                                        width: 260,
                                        height: 233,
                                        image_format: 'jpeg',
                                        jpeg_quality: 260
                                    });

                                    Webcam.attach('#my_camera');

                                    function take_snapshot() {
                                        Webcam.snap(function(data_uri) {
                                            $(".image-tag").val(data_uri);
                                            document.getElementById('results_img').innerHTML = '<img src="' + data_uri + '"/>';
                                            $('#captured_image').val(data_uri);
                                        });
                                    }
                                </script>

                            </div>
                        </div>
                        <div class="row">
                            <div class="footer">
                                <button type="submit" name="schktn" id="submit" onclick="validateForm()" class="button-block-b" data-keyboard="false" data-backdrop="static">Submit</button>
                            </div>
                        </div>
                </form>
            </div>

            <!-- QR Code Start -->
            <?php echo QrCode::size(150)->generate('https://techvblogs.com/blog/generate-qr-code-laravel-8'); ?>

            <!-- QR Code End -->

        </div>
        <div style="padding:25px; clear:both;"></div>
        <div class="visitor-instructions">
        </div>
    </div>


    <SCRIPT language=Javascript>
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

            return true;
        }
    </SCRIPT>


    <div class="footer-sction">
        <div class="container-fluid">
            <div class="col-xs-12 col-sm-6">Copyright © 2023, <a target="_blank" style="color: #fff; text-align: right; text-decoration: none;">Axepert Exhibits Pvt. Ltd.</a></div>
            <div class="col-xs-12 col-sm-6" style="text-align:right;">Powered by <a target="_blank" style="color: #fff; text-align: right; text-decoration: none;"> Axepert Exhibits Pvt. Ltd. </a></div>
        </div>
    </div>
    <section class="mangas" id="manga-area"></section>

</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script>
    function get_state(id, val) {
        var base_url = window.location.origin + "/";

        $.ajax({
            url: base_url + 'get_state',
            type: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                id: id
            },
            success: function(result) {
                $('.' + val).html(result.output);
            }

        })
    }

    function get_city(id, val) {
        var base_url = window.location.origin + "/";
        $.ajax({
            url: base_url + 'get_city',
            type: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                id: id
            },
            success: function(result) {
                $('.' + val).html(result.output);
            }

        })
    }

    $(document).on('submit', '#add_visitors', function(ev) {
        $('.error').html('');

        ev.preventDefault(); // Prevent browers default submit.
        var formData = new FormData(this);
        var error = false;

        if (error == false) {
            $.ajax({
                url: "<?php echo e(url('add_visitors')); ?> ",
                type: 'post',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(result) {
                    if (result.code == 200) {
                        alert(result.message);
                        setTimeout(function() {
                            window.location.href = "<?php echo e(url('thank_you/')); ?>" +result.id;
                        }, 1000);
                    } else if (result.code == 401) {
                        $.each(result.message, function(prefix, val) {
                            $('#' + prefix + '_error').text(val[0]);
                        });
                        $('.error').css('color', 'red');
                    }
                },
                error: function(xhr) {
                    $(".submitbtn").css('display', 'block');
                },
                complete: function() {
                    $(".submitbtn").css('display', 'block');
                },
            })
        }
    })
</script>

</html><?php /**PATH C:\laravelprojects\vms\resources\views/index.blade.php ENDPATH**/ ?>